#!/bin/bash

# Tailscale Complete Debug and Fix Script
# This script diagnoses and fixes Tailscale connectivity issues

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

log() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Function to run command with timeout and capture output
run_cmd() {
    local cmd="$1"
    local timeout="${2:-30}"
    local desc="${3:-Running command}"
    
    log "$desc: $cmd"
    if timeout "$timeout" bash -c "$cmd" 2>&1; then
        return 0
    else
        local ret=$?
        error "Command failed with exit code $ret"
        return $ret
    fi
}

# Check if running as root
check_root() {
    if [[ $EUID -ne 0 ]]; then
        error "This script must be run as root"
        echo "Please run: sudo $0"
        exit 1
    fi
}

# Check system requirements
check_requirements() {
    log "Checking system requirements..."
    
    # Check if systemd is available
    if ! command -v systemctl >/dev/null 2>&1; then
        error "systemctl not found. This script requires systemd."
        exit 1
    fi
    
    # Check internet connectivity
    if ! ping -c 1 8.8.8.8 >/dev/null 2>&1; then
        error "No internet connectivity detected"
        exit 1
    fi
    
    success "System requirements met"
}

# Install or update Tailscale
install_tailscale() {
    log "Installing/updating Tailscale..."
    
    if command -v tailscale >/dev/null 2>&1; then
        log "Tailscale already installed, checking version..."
        tailscale version
    else
        log "Installing Tailscale..."
        curl -fsSL https://tailscale.com/install.sh | sh
    fi
    
    success "Tailscale installation complete"
}

# Fix Tailscale service
fix_service() {
    log "Fixing Tailscale service..."
    
    # Stop everything first
    tailscale down 2>/dev/null || true
    systemctl stop tailscaled 2>/dev/null || true
    
    # Kill any hanging processes
    pkill -f tailscaled 2>/dev/null || true
    sleep 2
    
    # Clean up state if needed
    if [[ -f /var/lib/tailscale/tailscaled.state ]]; then
        log "Backing up existing state..."
        cp /var/lib/tailscale/tailscaled.state /var/lib/tailscale/tailscaled.state.backup.$(date +%s)
    fi
    
    # Ensure directories exist
    mkdir -p /var/lib/tailscale
    mkdir -p /run/tailscale
    
    # Start service
    systemctl enable tailscaled
    systemctl start tailscaled
    
    # Wait for service to be ready
    local retries=10
    while [[ $retries -gt 0 ]]; do
        if systemctl is-active --quiet tailscaled; then
            success "Tailscaled service is running"
            break
        fi
        log "Waiting for tailscaled to start... ($retries retries left)"
        sleep 2
        ((retries--))
    done
    
    if [[ $retries -eq 0 ]]; then
        error "Failed to start tailscaled service"
        systemctl status tailscaled --no-pager -l
        return 1
    fi
}

# Connect to Tailscale
connect_tailscale() {
    log "Connecting to Tailscale..."
    
    # Check if already connected
    local current_ip
    current_ip=$(tailscale ip -4 2>/dev/null || echo "")
    
    if [[ $current_ip =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
        success "Already connected with IP: $current_ip"
        return 0
    fi
    
    # Try to connect
    log "Running 'tailscale up' to get authentication URL..."
    
    # Create a temporary file for output
    local temp_file="/tmp/tailscale_up_output_$$"
    
    # Run tailscale up with timeout and capture output
    (
        timeout 20 tailscale up --accept-routes --accept-dns=false 2>&1 || true
    ) > "$temp_file" &
    
    local up_pid=$!
    sleep 15
    
    # Kill the process if still running
    if kill -0 $up_pid 2>/dev/null; then
        kill $up_pid 2>/dev/null || true
        wait $up_pid 2>/dev/null || true
    fi
    
    # Read output
    local output=""
    if [[ -f "$temp_file" ]]; then
        output=$(cat "$temp_file")
        rm -f "$temp_file"
    fi
    
    log "Tailscale up output:"
    echo "$output"
    
    # Extract authentication URL
    local auth_url
    auth_url=$(echo "$output" | grep -o 'https://login\.tailscale\.com/[^[:space:]]*' | head -1 | sed 's/[.,]*$//')
    
    if [[ -n "$auth_url" ]]; then
        success "Authentication URL found:"
        echo
        echo "🔗 $auth_url"
        echo
        warning "IMPORTANT: You must visit this URL in your browser to authenticate!"
        warning "After authentication, run this script again to verify connection."
        return 2  # Special return code for "needs authentication"
    fi
    
    # Check if connected now
    current_ip=$(tailscale ip -4 2>/dev/null || echo "")
    if [[ $current_ip =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
        success "Connected with IP: $current_ip"
        return 0
    fi
    
    error "Failed to connect to Tailscale"
    return 1
}

# Verify connection
verify_connection() {
    log "Verifying Tailscale connection..."
    
    # Get IP
    local ip
    ip=$(tailscale ip -4 2>/dev/null || echo "")
    
    if [[ ! $ip =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
        error "No Tailscale IP assigned"
        return 1
    fi
    
    success "Tailscale IP: $ip"
    
    # Get status
    log "Tailscale status:"
    tailscale status
    
    # Test connectivity to Tailscale coordination server
    if tailscale ping --timeout=5s --c=1 $(tailscale status --json | grep -o '"TailscaleIPs":\["[^"]*"' | cut -d'"' -f4) 2>/dev/null; then
        success "Tailscale network connectivity verified"
    else
        warning "Could not verify Tailscale network connectivity"
    fi
    
    return 0
}

# Show troubleshooting info
show_troubleshooting() {
    echo
    log "=== Troubleshooting Information ==="
    echo
    echo "If Tailscale is still not working, check the following:"
    echo
    echo "1. Container Network Configuration:"
    echo "   - Ensure the container has proper network access"
    echo "   - Check if the container can reach the internet"
    echo "   - Verify no firewall is blocking Tailscale ports (41641/UDP)"
    echo
    echo "2. Authentication Issues:"
    echo "   - Make sure you completed authentication in the browser"
    echo "   - Check if your Tailscale account has the device listed"
    echo "   - Try: tailscale logout && tailscale up"
    echo
    echo "3. Service Issues:"
    echo "   - Check service logs: journalctl -u tailscaled -f"
    echo "   - Restart service: systemctl restart tailscaled"
    echo "   - Check service status: systemctl status tailscaled"
    echo
    echo "4. Network Issues:"
    echo "   - Test basic connectivity: ping 8.8.8.8"
    echo "   - Check DNS resolution: nslookup login.tailscale.com"
    echo "   - Verify no proxy is interfering"
    echo
    echo "5. AVM Panel Integration:"
    echo "   - The VPS shows 'online' based on LXC container status, not Tailscale"
    echo "   - Tailscale provides private IP networking, not VPS online status"
    echo "   - Check container status: lxc info <container_name>"
}

# Main execution
main() {
    echo "========================================"
    echo "    Tailscale Debug and Fix Script"
    echo "========================================"
    echo
    
    check_root
    check_requirements
    install_tailscale
    
    if ! fix_service; then
        error "Failed to fix Tailscale service"
        exit 1
    fi
    
    local connect_result
    connect_tailscale
    connect_result=$?
    
    case $connect_result in
        0)
            success "Tailscale is fully connected!"
            verify_connection
            ;;
        2)
            warning "Authentication required - please visit the URL above"
            ;;
        *)
            error "Failed to connect to Tailscale"
            show_troubleshooting
            exit 1
            ;;
    esac
    
    echo
    success "Script completed successfully!"
    
    if [[ $connect_result -eq 0 ]]; then
        echo
        log "Your Tailscale private IP is: $(tailscale ip -4)"
        log "You can now use this IP to connect to your VPS privately"
    fi
}

# Run main function
main "$@"