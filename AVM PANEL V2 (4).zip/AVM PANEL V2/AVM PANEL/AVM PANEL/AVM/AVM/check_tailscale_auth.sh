#!/bin/bash

# Quick Tailscale Authentication Check Script

echo "=== Tailscale Authentication Checker ==="
echo

# Check if tailscale is installed
if ! command -v tailscale >/dev/null 2>&1; then
    echo "❌ Tailscale not installed"
    exit 1
fi

echo "✅ Tailscale is installed"
echo "Version: $(tailscale version --short 2>/dev/null || tailscale version)"
echo

# Check service status
if systemctl is-active --quiet tailscaled; then
    echo "✅ Tailscaled service is running"
else
    echo "❌ Tailscaled service is not running"
    echo "Starting service..."
    sudo systemctl start tailscaled
    sleep 3
    if systemctl is-active --quiet tailscaled; then
        echo "✅ Service started successfully"
    else
        echo "❌ Failed to start service"
        sudo systemctl status tailscaled --no-pager -l
        exit 1
    fi
fi

echo

# Check current status
echo "=== Current Tailscale Status ==="
tailscale status 2>/dev/null || echo "No status available (not authenticated)"
echo

# Check if we have an IP
CURRENT_IP=$(tailscale ip -4 2>/dev/null || echo "")
if [[ $CURRENT_IP =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
    echo "✅ Already authenticated and connected!"
    echo "Tailscale IP: $CURRENT_IP"
    echo
    echo "Testing connectivity..."
    if ping -c 1 -W 3 $CURRENT_IP >/dev/null 2>&1; then
        echo "✅ Tailscale IP is reachable"
    else
        echo "⚠️  Tailscale IP might not be fully configured"
    fi
    exit 0
fi

echo "❌ Not authenticated or no IP assigned"
echo

# Try to get fresh auth URL
echo "=== Getting Fresh Authentication URL ==="
echo "This will generate a new authentication URL..."
echo

# Logout first to get fresh auth
tailscale logout >/dev/null 2>&1 || true
sleep 2

# Get new auth URL
echo "Running 'tailscale up' to get authentication URL..."
timeout 15 tailscale up --accept-routes --accept-dns=false > /tmp/ts_auth_check.log 2>&1 &
UP_PID=$!

# Wait a bit then kill the process
sleep 10
if kill -0 $UP_PID 2>/dev/null; then
    kill $UP_PID 2>/dev/null || true
fi

# Read the output
if [[ -f /tmp/ts_auth_check.log ]]; then
    OUTPUT=$(cat /tmp/ts_auth_check.log)
    echo "Output:"
    echo "$OUTPUT"
    echo
    
    # Extract auth URL
    AUTH_URL=$(echo "$OUTPUT" | grep -o 'https://login\.tailscale\.com/[^[:space:]]*' | head -1 | sed 's/[.,]*$//')
    
    if [[ -n "$AUTH_URL" ]]; then
        echo "🔗 Authentication URL:"
        echo "$AUTH_URL"
        echo
        echo "📋 Instructions:"
        echo "1. Copy the URL above"
        echo "2. Open it in your web browser"
        echo "3. Log in to your Tailscale account"
        echo "4. Authorize this device"
        echo "5. Run this script again to verify"
        echo
        echo "💡 Tip: The URL should work immediately. If you get an error page:"
        echo "   - Make sure you're logged into the correct Tailscale account"
        echo "   - Try copying the URL manually (avoid auto-click)"
        echo "   - Check if your account has device limits"
    else
        echo "❌ Could not extract authentication URL from output"
        echo "This might indicate a network or service issue"
    fi
    
    rm -f /tmp/ts_auth_check.log
else
    echo "❌ No output captured from tailscale up command"
fi

echo
echo "=== Troubleshooting Tips ==="
echo "• If the auth URL doesn't work, try: sudo tailscale logout && sudo tailscale up"
echo "• Check your Tailscale account at https://login.tailscale.com/admin/machines"
echo "• Ensure this device isn't already registered with a different name"
echo "• Verify your account isn't at the device limit"
echo "• Check network connectivity: ping login.tailscale.com"