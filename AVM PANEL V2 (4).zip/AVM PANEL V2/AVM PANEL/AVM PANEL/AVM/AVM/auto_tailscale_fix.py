#!/usr/bin/env python3
"""
Automated Tailscale Fix for AVM Panel
This script automatically diagnoses and fixes Tailscale issues without manual intervention
"""

import subprocess
import time
import re
import json
import sys
import os
from typing import Dict, Optional, Tuple

class TailscaleAutoFix:
    def __init__(self):
        self.log_messages = []
        
    def log(self, message: str, level: str = "INFO"):
        timestamp = time.strftime("%Y-%m-%d %H:%M:%S")
        log_entry = f"[{timestamp}] [{level}] {message}"
        self.log_messages.append(log_entry)
        print(log_entry)
    
    def run_command(self, cmd: str, timeout: int = 30, check_return: bool = True) -> Tuple[int, str, str]:
        """Run a command and return (returncode, stdout, stderr)"""
        try:
            self.log(f"Running: {cmd}")
            result = subprocess.run(
                cmd, 
                shell=True, 
                capture_output=True, 
                text=True, 
                timeout=timeout
            )
            
            if check_return and result.returncode != 0:
                self.log(f"Command failed with code {result.returncode}: {result.stderr}", "ERROR")
            
            return result.returncode, result.stdout, result.stderr
            
        except subprocess.TimeoutExpired:
            self.log(f"Command timed out after {timeout}s", "ERROR")
            return -1, "", "Command timed out"
        except Exception as e:
            self.log(f"Command execution error: {e}", "ERROR")
            return -1, "", str(e)
    
    def check_system_requirements(self) -> bool:
        """Check if system meets requirements"""
        self.log("Checking system requirements...")
        
        # Check if running as root
        if os.geteuid() != 0:
            self.log("Not running as root, attempting to use sudo", "WARNING")
        
        # Check internet connectivity
        ret, _, _ = self.run_command("ping -c 1 -W 5 8.8.8.8", check_return=False)
        if ret != 0:
            self.log("No internet connectivity", "ERROR")
            return False
        
        # Check systemctl
        ret, _, _ = self.run_command("which systemctl", check_return=False)
        if ret != 0:
            self.log("systemctl not available", "ERROR")
            return False
        
        self.log("System requirements met")
        return True
    
    def install_tailscale(self) -> bool:
        """Install or update Tailscale"""
        self.log("Checking Tailscale installation...")
        
        # Check if already installed
        ret, out, _ = self.run_command("which tailscale", check_return=False)
        if ret == 0:
            self.log("Tailscale already installed")
            ret, version, _ = self.run_command("tailscale version --short", check_return=False)
            if ret == 0:
                self.log(f"Current version: {version.strip()}")
            return True
        
        # Install Tailscale
        self.log("Installing Tailscale...")
        ret, out, err = self.run_command("curl -fsSL https://tailscale.com/install.sh | sh", timeout=180)
        
        if ret != 0:
            self.log(f"Failed to install Tailscale: {err}", "ERROR")
            return False
        
        self.log("Tailscale installed successfully")
        return True
    
    def fix_tailscale_service(self) -> bool:
        """Fix Tailscale service issues"""
        self.log("Fixing Tailscale service...")
        
        # Stop everything
        self.run_command("tailscale down", check_return=False)
        self.run_command("systemctl stop tailscaled", check_return=False)
        self.run_command("pkill -f tailscaled", check_return=False)
        time.sleep(2)
        
        # Ensure directories exist
        self.run_command("mkdir -p /var/lib/tailscale /run/tailscale", check_return=False)
        
        # Start service
        self.run_command("systemctl enable tailscaled")
        ret, _, err = self.run_command("systemctl start tailscaled")
        
        if ret != 0:
            self.log(f"Failed to start tailscaled: {err}", "ERROR")
            return False
        
        # Wait for service to be ready
        for i in range(10):
            ret, out, _ = self.run_command("systemctl is-active tailscaled", check_return=False)
            if "active" in out:
                self.log("Tailscaled service is running")
                return True
            time.sleep(2)
        
        self.log("Tailscaled service failed to start properly", "ERROR")
        return False
    
    def get_tailscale_status(self) -> Dict:
        """Get current Tailscale status"""
        status = {
            'installed': False,
            'service_active': False,
            'authenticated': False,
            'ip': None,
            'needs_auth': False,
            'auth_url': None
        }
        
        # Check if installed
        ret, _, _ = self.run_command("which tailscale", check_return=False)
        if ret != 0:
            return status
        status['installed'] = True
        
        # Check service
        ret, out, _ = self.run_command("systemctl is-active tailscaled", check_return=False)
        status['service_active'] = "active" in out
        
        if not status['service_active']:
            return status
        
        # Check IP
        ret, out, _ = self.run_command("tailscale ip -4", check_return=False)
        if ret == 0 and re.match(r'^\d+\.\d+\.\d+\.\d+$', out.strip()):
            status['authenticated'] = True
            status['ip'] = out.strip()
        
        return status
    
    def authenticate_tailscale(self) -> Optional[str]:
        """Attempt to get authentication URL or authenticate automatically"""
        self.log("Attempting Tailscale authentication...")
        
        # First, logout to get fresh state
        self.run_command("tailscale logout", check_return=False)
        time.sleep(2)
        
        # Try to run tailscale up and capture auth URL
        self.log("Running tailscale up to get auth URL...")
        
        # Use a background process to capture the auth URL
        cmd = "timeout 15 tailscale up --accept-routes --accept-dns=false"
        ret, out, err = self.run_command(cmd, timeout=20, check_return=False)
        
        # Combine stdout and stderr to look for auth URL
        combined_output = out + err
        self.log(f"Tailscale up output: {combined_output}")
        
        # Extract auth URL
        auth_url_match = re.search(r'https://login\.tailscale\.com/[^\s]+', combined_output)
        if auth_url_match:
            auth_url = auth_url_match.group(0).rstrip('.,')
            self.log(f"Found auth URL: {auth_url}")
            return auth_url
        
        # Check if already authenticated
        ret, ip_out, _ = self.run_command("tailscale ip -4", check_return=False)
        if ret == 0 and re.match(r'^\d+\.\d+\.\d+\.\d+$', ip_out.strip()):
            self.log(f"Already authenticated with IP: {ip_out.strip()}")
            return ip_out.strip()
        
        self.log("Could not get auth URL or authenticate", "ERROR")
        return None
    
    def wait_for_authentication(self, timeout: int = 300) -> Optional[str]:
        """Wait for user to complete authentication"""
        self.log(f"Waiting up to {timeout} seconds for authentication...")
        
        start_time = time.time()
        while time.time() - start_time < timeout:
            ret, out, _ = self.run_command("tailscale ip -4", check_return=False)
            if ret == 0 and re.match(r'^\d+\.\d+\.\d+\.\d+$', out.strip()):
                ip = out.strip()
                self.log(f"Authentication successful! IP: {ip}")
                return ip
            
            time.sleep(5)
        
        self.log("Authentication timeout", "ERROR")
        return None
    
    def verify_connectivity(self, ip: str) -> bool:
        """Verify Tailscale connectivity"""
        self.log(f"Verifying connectivity for IP {ip}...")
        
        # Test basic tailscale status
        ret, out, _ = self.run_command("tailscale status", check_return=False)
        if ret == 0:
            self.log("Tailscale status looks good")
            return True
        
        self.log("Tailscale status check failed", "WARNING")
        return False
    
    def create_status_report(self) -> Dict:
        """Create a comprehensive status report"""
        status = self.get_tailscale_status()
        
        report = {
            'timestamp': time.strftime("%Y-%m-%d %H:%M:%S"),
            'status': status,
            'logs': self.log_messages,
            'recommendations': []
        }
        
        if not status['installed']:
            report['recommendations'].append("Install Tailscale")
        elif not status['service_active']:
            report['recommendations'].append("Fix Tailscale service")
        elif not status['authenticated']:
            report['recommendations'].append("Complete authentication")
        else:
            report['recommendations'].append("Tailscale is working properly")
        
        return report
    
    def auto_fix(self) -> Dict:
        """Automatically fix Tailscale issues"""
        self.log("Starting automated Tailscale fix...")
        
        try:
            # Check system requirements
            if not self.check_system_requirements():
                return self.create_status_report()
            
            # Install Tailscale if needed
            if not self.install_tailscale():
                return self.create_status_report()
            
            # Fix service issues
            if not self.fix_tailscale_service():
                return self.create_status_report()
            
            # Check current status
            status = self.get_tailscale_status()
            
            if status['authenticated']:
                self.log(f"Tailscale already working with IP: {status['ip']}")
                self.verify_connectivity(status['ip'])
                return self.create_status_report()
            
            # Try to authenticate
            auth_result = self.authenticate_tailscale()
            
            if auth_result and re.match(r'^\d+\.\d+\.\d+\.\d+$', auth_result):
                # Already authenticated
                self.log("Tailscale is now working!")
                self.verify_connectivity(auth_result)
            elif auth_result and auth_result.startswith('http'):
                # Got auth URL - in a real automated system, you might:
                # 1. Store this URL for the user
                # 2. Send it via notification
                # 3. Display it in the panel
                self.log(f"Authentication required: {auth_result}")
                
                # For automation, we could wait a bit to see if user authenticates
                self.log("Checking if authentication completes automatically...")
                ip = self.wait_for_authentication(60)  # Wait 1 minute
                
                if ip:
                    self.log("Authentication completed automatically!")
                    self.verify_connectivity(ip)
                else:
                    self.log("Manual authentication required", "WARNING")
            else:
                self.log("Failed to get authentication URL", "ERROR")
            
            return self.create_status_report()
            
        except Exception as e:
            self.log(f"Unexpected error during auto-fix: {e}", "ERROR")
            return self.create_status_report()

def main():
    """Main function for command line usage"""
    fixer = TailscaleAutoFix()
    
    if len(sys.argv) > 1 and sys.argv[1] == "--status-only":
        # Just check status
        status = fixer.get_tailscale_status()
        print(json.dumps(status, indent=2))
    else:
        # Run full auto-fix
        report = fixer.auto_fix()
        
        print("\n" + "="*50)
        print("TAILSCALE AUTO-FIX REPORT")
        print("="*50)
        print(json.dumps(report, indent=2))
        
        # Return appropriate exit code
        if report['status']['authenticated']:
            sys.exit(0)  # Success
        else:
            sys.exit(1)  # Needs attention

if __name__ == "__main__":
    main()