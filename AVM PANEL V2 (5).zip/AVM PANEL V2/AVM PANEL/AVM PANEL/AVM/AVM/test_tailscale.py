#!/usr/bin/env python3
"""
Tailscale integration test — simulates exactly what the AVM panel does
inside the LXC container, without needing Flask running.

Usage:
    python3 test_tailscale.py <container_name> [node_id]

Example:
    python3 test_tailscale.py avm-vps-1-1
    python3 test_tailscale.py avm-vps-1-1 1
"""

import subprocess
import sys
import re
import time
import json

# ── Config ────────────────────────────────────────────────────────────────────
CONTAINER  = sys.argv[1] if len(sys.argv) > 1 else "avm-vps-1-1"
NODE_LOCAL = True   # set False if remote node
TIMEOUT_DEFAULT = 30

# ── Helpers ───────────────────────────────────────────────────────────────────
PASS = "\033[92m✔\033[0m"
FAIL = "\033[91m✘\033[0m"
WARN = "\033[93m⚠\033[0m"
INFO = "\033[94mℹ\033[0m"

results = []

def lxc(cmd, timeout=TIMEOUT_DEFAULT, fatal=False):
    """Run a command inside the LXC container and return stdout."""
    full = f'lxc exec {CONTAINER} -- sh -c "{cmd}"'
    try:
        r = subprocess.run(full, shell=True, capture_output=True, text=True, timeout=timeout)
        out = (r.stdout or "").strip()
        err = (r.stderr or "").strip()
        combined = (out + "\n" + err).strip()
        if r.returncode != 0 and fatal:
            raise RuntimeError(f"exit {r.returncode}: {err or out}")
        return combined
    except subprocess.TimeoutExpired:
        if fatal:
            raise RuntimeError(f"Command timed out after {timeout}s")
        return ""
    except Exception as e:
        if fatal:
            raise
        return ""

def check(name, result, detail=""):
    icon = PASS if result else FAIL
    print(f"  {icon}  {name}" + (f"  →  {detail}" if detail else ""))
    results.append((name, result, detail))
    return result

def section(title):
    print(f"\n\033[1m{'─'*55}\033[0m")
    print(f"\033[1m  {title}\033[0m")
    print(f"\033[1m{'─'*55}\033[0m")

# ── Tests ─────────────────────────────────────────────────────────────────────

section("1 · Container Reachability")
ping = lxc("echo pong", timeout=8)
if not check("Container responds to exec", ping == "pong", ping or "no response"):
    print(f"\n  {FAIL}  Cannot reach container '{CONTAINER}'. Aborting.\n")
    sys.exit(1)

section("2 · Basic Tools")
for tool in ["curl", "sh", "cat", "pgrep", "kill", "timeout", "nohup"]:
    out = lxc(f"which {tool} 2>/dev/null && echo yes || echo no")
    check(f"{tool} available", "yes" in out, out)

section("3 · Tailscale Installation")
ts_installed = lxc("which tailscale 2>/dev/null && echo yes || echo no")
if "yes" not in ts_installed:
    print(f"  {WARN}  Tailscale not installed — testing install...")
    install_out = lxc("curl -fsSL https://tailscale.com/install.sh | sh 2>&1 | tail -5", timeout=180)
    ts_installed = lxc("which tailscale 2>/dev/null && echo yes || echo no")
    check("Tailscale installed successfully", "yes" in ts_installed, install_out[-200:] if install_out else "")
else:
    check("Tailscale already installed", True)
    ver = lxc("tailscale version --short 2>/dev/null || tailscale version 2>/dev/null | head -1")
    check("Tailscale version readable", bool(ver), ver)

section("4 · Tailscaled Daemon")
# Kill stale
lxc("kill $(pgrep tailscaled 2>/dev/null) 2>/dev/null || true", timeout=8)
time.sleep(1)

# Ensure dirs
lxc("mkdir -p /var/lib/tailscale /run/tailscale", timeout=8)

# Start daemon
lxc(
    "nohup tailscaled --state=/var/lib/tailscale/tailscaled.state "
    "--socket=/run/tailscale/tailscaled.sock "
    "> /tmp/tailscaled.log 2>&1 &",
    timeout=10
)
time.sleep(4)

daemon_running = lxc("pgrep -x tailscaled >/dev/null 2>&1 && echo running || echo not_running", timeout=8)
check("tailscaled daemon running", "running" in daemon_running, daemon_running)

daemon_log = lxc("cat /tmp/tailscaled.log 2>/dev/null | head -5")
if daemon_log:
    print(f"  {INFO}  daemon log: {daemon_log[:200]}")

section("5 · tailscale up — URL Capture")

# Attempt 1: --timeout flag (newer versions)
print(f"  {INFO}  Attempt 1: tailscale up --timeout=12s")
lxc("rm -f /tmp/ts_up.log /tmp/ts_up2.log", timeout=5)
lxc(
    "tailscale up --accept-routes --accept-dns=false --timeout=12s "
    "> /tmp/ts_up.log 2>&1 || true",
    timeout=20
)
time.sleep(1)
ts_out = lxc("cat /tmp/ts_up.log 2>/dev/null || true", timeout=8)
check("Attempt 1 produced output", bool(ts_out), ts_out[:120] if ts_out else "empty")

# Attempt 2: system timeout (older versions)
if "login.tailscale.com" not in ts_out:
    print(f"  {INFO}  Attempt 2: timeout 12 tailscale up")
    lxc(
        "timeout 12 tailscale up --accept-routes --accept-dns=false "
        "> /tmp/ts_up2.log 2>&1 || true",
        timeout=18
    )
    time.sleep(1)
    ts_out2 = lxc("cat /tmp/ts_up2.log 2>/dev/null || true", timeout=8)
    if ts_out2:
        ts_out = ts_out + "\n" + ts_out2
    check("Attempt 2 produced output", bool(ts_out2), ts_out2[:120] if ts_out2 else "empty")

# Attempt 3: tailscale status
if "login.tailscale.com" not in ts_out:
    print(f"  {INFO}  Attempt 3: tailscale status")
    status_out = lxc("tailscale status 2>/dev/null || true", timeout=8)
    if "login.tailscale.com" in (status_out or ""):
        ts_out = ts_out + "\n" + status_out
    check("Status contains URL", "login.tailscale.com" in (status_out or ""), (status_out or "")[:120])

# Extract URL
m = re.search(r'https://login\.tailscale\.com/\S+', ts_out)
login_url = m.group(0).rstrip(".,)") if m else ""
check("Login URL extracted", bool(login_url), login_url or "NOT FOUND")

if login_url:
    print(f"\n  \033[92m🔗  AUTH URL: {login_url}\033[0m\n")

section("6 · Already Connected?")
ip_out = lxc("tailscale ip -4 2>/dev/null || true", timeout=10)
ip_match = re.search(r'\d+\.\d+\.\d+\.\d+', ip_out or "")
tailscale_ip = ip_match.group(0) if ip_match else ""
check("Tailscale IP assigned", bool(tailscale_ip), tailscale_ip or "not connected yet")

section("7 · Full Output Captured")
print(f"  Combined ts_out ({len(ts_out)} chars):")
for line in ts_out.splitlines()[:20]:
    print(f"    {line}")
if len(ts_out.splitlines()) > 20:
    print(f"    ... ({len(ts_out.splitlines())-20} more lines)")

# ── Summary ───────────────────────────────────────────────────────────────────
section("SUMMARY")
passed = sum(1 for _, r, _ in results if r)
failed = sum(1 for _, r, _ in results if not r)
print(f"  {PASS} Passed: {passed}   {FAIL} Failed: {failed}\n")

if login_url:
    print(f"  \033[92m✔  SUCCESS — Auth URL ready:\033[0m")
    print(f"  \033[1m  {login_url}\033[0m")
elif tailscale_ip:
    print(f"  \033[92m✔  SUCCESS — Already connected: {tailscale_ip}\033[0m")
else:
    print(f"  \033[91m✘  FAILED — No URL and no IP captured.\033[0m")
    print(f"  Check the output above for clues.")
    print(f"\n  Raw tailscale up output:")
    print(f"  {repr(ts_out[:500])}")

print()

# Machine-readable result
result_json = {
    "container": CONTAINER,
    "login_url": login_url,
    "tailscale_ip": tailscale_ip,
    "passed": passed,
    "failed": failed,
    "ts_out_raw": ts_out[:1000]
}
with open("/tmp/tailscale_test_result.json", "w") as f:
    json.dump(result_json, f, indent=2)
print(f"  Result saved to /tmp/tailscale_test_result.json")
